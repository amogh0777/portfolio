import { Brain, Eye, Code, Database, BarChart3, Cpu } from 'lucide-react';

const skills = [
  {
    icon: Brain,
    title: 'Machine Learning & Deep Learning',
    description: 'Building intelligent systems that learn from data',
    level: 85
  },
  {
    icon: Cpu,
    title: 'Natural Language Processing',
    description: 'Processing and understanding human language',
    level: 80
  },
  {
    icon: Eye,
    title: 'Computer Vision',
    description: 'Enabling machines to interpret visual information',
    level: 75
  },
  {
    icon: Code,
    title: 'Python Programming',
    description: 'Advanced proficiency in Python for AI/ML development',
    level: 90
  },
  {
    icon: Database,
    title: 'Big Data Analytics',
    description: 'Processing and analyzing large-scale datasets',
    level: 75
  },
  {
    icon: BarChart3,
    title: 'Data Visualization',
    description: 'Creating insightful visual representations of data',
    level: 80
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 px-4 bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-slate-900 mb-4">
          Skills & Expertise
        </h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto mb-12"></div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-shadow border border-slate-200"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <skill.icon className="text-blue-600" size={28} />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-slate-900 mb-1">
                    {skill.title}
                  </h3>
                  <p className="text-sm text-slate-600">
                    {skill.description}
                  </p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Proficiency</span>
                  <span className="text-blue-600 font-semibold">{skill.level}%</span>
                </div>
                <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full transition-all duration-1000"
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white p-8 rounded-xl shadow-md border border-slate-200">
          <h3 className="text-2xl font-bold text-slate-900 mb-6 text-center">
            Additional Competencies
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">Problem Solving</div>
              <p className="text-slate-600">Analytical thinking and systematic approach</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">Innovation</div>
              <p className="text-slate-600">Creative solutions to complex challenges</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">Research</div>
              <p className="text-slate-600">Staying current with AI/ML advancements</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
