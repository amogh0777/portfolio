import { ArrowRight, Github, Linkedin, Mail, Phone } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 px-4 py-20">
      <div className="max-w-6xl w-full mx-auto">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4">
              Hi, I'm <span className="text-blue-600">Amogh SR</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-600 mb-6">
              CSE Undergraduate | AI/ML Specialist
            </p>
            <p className="text-lg text-slate-700 mb-8 leading-relaxed">
              I'm passionate about Machine Learning, NLP, Computer Vision, and Big Data Analytics.
              I enjoy problem-solving, innovating, and taking on new tech challenges.
            </p>
            <div className="flex flex-wrap gap-4 justify-center md:justify-start mb-8">
              <a
                href="#projects"
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 font-medium"
              >
                View Portfolio <ArrowRight size={20} />
              </a>
              <a
                href="#contact"
                className="px-6 py-3 bg-slate-200 text-slate-900 rounded-lg hover:bg-slate-300 transition-colors font-medium"
              >
                Contact Me
              </a>
            </div>
            <div className="flex gap-4 justify-center md:justify-start">
              <a
                href="https://github.com/amogh0777"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white rounded-full shadow-md hover:shadow-lg transition-shadow text-slate-700 hover:text-blue-600"
              >
                <Github size={24} />
              </a>
              <a
                href="https://www.linkedin.com/in/amogh-sr"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white rounded-full shadow-md hover:shadow-lg transition-shadow text-slate-700 hover:text-blue-600"
              >
                <Linkedin size={24} />
              </a>
              <a
                href="mailto:aamoghsr@gmail.com"
                className="p-3 bg-white rounded-full shadow-md hover:shadow-lg transition-shadow text-slate-700 hover:text-blue-600"
              >
                <Mail size={24} />
              </a>
              <a
                href="tel:9901765579"
                className="p-3 bg-white rounded-full shadow-md hover:shadow-lg transition-shadow text-slate-700 hover:text-blue-600"
              >
                <Phone size={24} />
              </a>
            </div>
          </div>
          <div className="flex-shrink-0">
            <div className="w-72 h-72 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 shadow-2xl flex items-center justify-center text-white text-8xl font-bold">
              AS
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
