import { GraduationCap, Brain, Code, Lightbulb } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-slate-900 mb-4">
          About Me
        </h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto mb-12"></div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <div className="space-y-6">
            <p className="text-lg text-slate-700 leading-relaxed">
              I'm currently pursuing my <span className="font-semibold text-blue-600">B.Tech in Computer Science Engineering</span> with
              a specialization in <span className="font-semibold text-blue-600">Artificial Intelligence and Machine Learning</span> at
              CMR University. Expected to graduate in 2027, I'm on an exciting journey to master the cutting-edge technologies
              that are shaping our future.
            </p>
            <p className="text-lg text-slate-700 leading-relaxed">
              My passion lies in exploring the depths of Machine Learning, Deep Learning, Natural Language Processing,
              and Computer Vision. I believe in the power of data-driven solutions and innovative problem-solving to
              tackle real-world challenges.
            </p>
            <p className="text-lg text-slate-700 leading-relaxed">
              With a strong foundation in Python programming and a growing expertise in Big Data Analytics and
              Data Visualization, I'm constantly seeking opportunities to learn, experiment, and contribute to
              the AI/ML community.
            </p>
          </div>

          <div className="space-y-4">
            <div className="bg-gradient-to-br from-blue-50 to-slate-50 p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <GraduationCap className="text-blue-600" size={28} />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-2">Education</h3>
                  <p className="text-slate-700">B.Tech CSE (AI/ML)</p>
                  <p className="text-slate-600 text-sm">CMR University</p>
                  <p className="text-slate-500 text-sm">Expected Graduation: 2027</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-slate-50 p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Brain className="text-blue-600" size={28} />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-2">Focus Areas</h3>
                  <p className="text-slate-700">AI, ML, Deep Learning, NLP, Computer Vision</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-slate-50 p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Code className="text-blue-600" size={28} />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-2">Technical Proficiency</h3>
                  <p className="text-slate-700">Python, Data Analytics, Visualization Tools</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-slate-50 p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Lightbulb className="text-blue-600" size={28} />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-slate-900 mb-2">Mindset</h3>
                  <p className="text-slate-700">Problem-solving, Innovation, Continuous Learning</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
