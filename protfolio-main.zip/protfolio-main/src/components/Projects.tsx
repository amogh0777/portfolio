import { Microscope, Lightbulb, Rocket } from 'lucide-react';

const projects = [
  {
    icon: Microscope,
    title: 'AI/ML Research & Experimentation',
    description: 'Exploring various machine learning algorithms and deep learning architectures through hands-on experimentation. Working with popular frameworks and datasets to understand model behavior and optimization techniques.',
    technologies: ['Python', 'TensorFlow', 'PyTorch', 'Scikit-learn'],
    status: 'Ongoing'
  },
  {
    icon: Lightbulb,
    title: 'NLP Learning Projects',
    description: 'Diving deep into Natural Language Processing by implementing text classification, sentiment analysis, and language modeling tasks. Experimenting with transformers and pre-trained models.',
    technologies: ['Python', 'NLTK', 'spaCy', 'Hugging Face'],
    status: 'In Progress'
  },
  {
    icon: Rocket,
    title: 'Computer Vision Explorations',
    description: 'Building computer vision applications for image classification, object detection, and image segmentation. Learning state-of-the-art architectures and their practical implementations.',
    technologies: ['Python', 'OpenCV', 'CNN', 'YOLO'],
    status: 'Learning Phase'
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-slate-900 mb-4">
          Projects & Learning Journey
        </h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
        <p className="text-center text-slate-600 mb-12 max-w-2xl mx-auto">
          Currently building my expertise through hands-on learning and experimentation.
          More projects coming soon as I continue my AI/ML journey.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-slate-50 to-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all border border-slate-200 hover:border-blue-300"
            >
              <div className="mb-4">
                <div className="inline-block p-4 bg-blue-100 rounded-lg mb-4">
                  <project.icon className="text-blue-600" size={32} />
                </div>
                <div className="inline-block ml-2 px-3 py-1 bg-blue-100 text-blue-700 text-sm font-medium rounded-full">
                  {project.status}
                </div>
              </div>

              <h3 className="font-bold text-xl text-slate-900 mb-3">
                {project.title}
              </h3>

              <p className="text-slate-600 mb-4 leading-relaxed">
                {project.description}
              </p>

              <div className="flex flex-wrap gap-2">
                {project.technologies.map((tech, techIndex) => (
                  <span
                    key={techIndex}
                    className="px-3 py-1 bg-slate-100 text-slate-700 text-sm rounded-md"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-block bg-gradient-to-r from-blue-50 to-slate-50 p-8 rounded-xl border border-slate-200">
            <h3 className="text-2xl font-bold text-slate-900 mb-3">
              More Projects Coming Soon
            </h3>
            <p className="text-slate-600 max-w-xl">
              I'm continuously working on new projects and expanding my portfolio.
              Check back regularly to see my latest work in AI, Machine Learning, and Data Science.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
