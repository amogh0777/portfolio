import { Brain, BarChart3, Users } from 'lucide-react';

const services = [
  {
    icon: Brain,
    title: 'AI & Machine Learning Solutions',
    description: 'Developing intelligent systems using cutting-edge machine learning algorithms and deep learning techniques. From predictive modeling to neural networks, I bring AI-powered solutions to real-world problems.',
    features: [
      'Custom ML model development',
      'Deep learning implementation',
      'Model optimization & tuning',
      'AI-powered automation'
    ]
  },
  {
    icon: BarChart3,
    title: 'Data Analysis & Visualization',
    description: 'Transforming raw data into actionable insights through comprehensive analysis and compelling visualizations. Expertise in handling big data and creating intuitive dashboards for decision-making.',
    features: [
      'Big data processing',
      'Statistical analysis',
      'Interactive dashboards',
      'Predictive analytics'
    ]
  },
  {
    icon: Users,
    title: 'Collaboration & Learning',
    description: 'Open to collaborating on innovative AI/ML projects and research initiatives. Eager to contribute to meaningful projects while continuing to learn and grow in the ever-evolving field of artificial intelligence.',
    features: [
      'Research collaboration',
      'Open-source contributions',
      'Knowledge sharing',
      'Team projects'
    ]
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 px-4 bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-slate-900 mb-4">
          What I Offer
        </h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
        <p className="text-center text-slate-600 mb-12 max-w-2xl mx-auto">
          Leveraging my expertise in AI/ML to deliver innovative solutions and collaborate on exciting projects
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all border border-slate-200"
            >
              <div className="inline-block p-4 bg-gradient-to-br from-blue-100 to-blue-50 rounded-xl mb-6">
                <service.icon className="text-blue-600" size={36} />
              </div>

              <h3 className="font-bold text-2xl text-slate-900 mb-4">
                {service.title}
              </h3>

              <p className="text-slate-600 mb-6 leading-relaxed">
                {service.description}
              </p>

              <ul className="space-y-3">
                {service.features.map((feature, featureIndex) => (
                  <li
                    key={featureIndex}
                    className="flex items-center gap-3 text-slate-700"
                  >
                    <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white p-8 rounded-xl shadow-md border border-slate-200 text-center">
          <h3 className="text-2xl font-bold text-slate-900 mb-4">
            Let's Work Together
          </h3>
          <p className="text-slate-600 max-w-2xl mx-auto mb-6">
            I'm always excited to collaborate on innovative AI/ML projects, contribute to research,
            or discuss new opportunities in the field of artificial intelligence. Let's create something amazing together!
          </p>
          <a
            href="#contact"
            className="inline-block px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Get In Touch
          </a>
        </div>
      </div>
    </section>
  );
}
