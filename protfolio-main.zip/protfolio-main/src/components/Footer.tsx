import { Github, Linkedin, Mail, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-2xl font-bold text-blue-400 mb-4">Amogh SR</h3>
            <p className="text-slate-300 leading-relaxed">
              AI/ML enthusiast passionate about creating intelligent solutions
              and pushing the boundaries of technology.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <div className="space-y-2">
              <a href="#about" className="block text-slate-300 hover:text-blue-400 transition-colors">About</a>
              <a href="#skills" className="block text-slate-300 hover:text-blue-400 transition-colors">Skills</a>
              <a href="#projects" className="block text-slate-300 hover:text-blue-400 transition-colors">Projects</a>
              <a href="#contact" className="block text-slate-300 hover:text-blue-400 transition-colors">Contact</a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Connect</h4>
            <div className="flex gap-4">
              <a
                href="https://github.com/amogh0777"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-slate-800 rounded-full hover:bg-blue-600 transition-colors"
              >
                <Github size={20} />
              </a>
              <a
                href="https://www.linkedin.com/in/amogh-sr"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-slate-800 rounded-full hover:bg-blue-600 transition-colors"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="mailto:aamoghsr@gmail.com"
                className="p-3 bg-slate-800 rounded-full hover:bg-blue-600 transition-colors"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 text-center">
          <p className="text-slate-400 flex items-center justify-center gap-2">
            Made with <Heart size={16} className="text-red-500" /> by Amogh SR
          </p>
          <p className="text-slate-500 text-sm mt-2">
            {new Date().getFullYear()} All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
